package uk.ac.glasgow.internman;

public enum UoGGrade {
A1,A2,A3,A4,A5,B1,B2,B3,C1,C2,C3,D1,D2,D3,E1,E2,E3,F1,F2,F3,G,H
}
