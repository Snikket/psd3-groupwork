package uk.ac.glasgow.clui;

public class SystemCommandException extends Exception {
	
	public SystemCommandException(String message, Exception cause) {
		super(message,cause);
	}

	public SystemCommandException(String message) {
		super(message);
	}

	/****/
	private static final long serialVersionUID = -6768621131724501725L;

}
